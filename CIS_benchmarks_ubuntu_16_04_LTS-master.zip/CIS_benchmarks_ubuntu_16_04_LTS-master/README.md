# CIS_benchmarks_ubuntu_16_04_LTS
Script to automate checking CIS benchmarks for Ubuntu 16.04

The script does not make any changes, but does check if it passes or fails the check and provides the output from the CIS Benchmarks document.  The script works best when run as the root user. 
